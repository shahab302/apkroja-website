from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    slug = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.Text)
    icon = db.Column(db.String(50))  # Icon name for UI
    color = db.Column(db.String(20))  # Color for UI
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship
    apps = db.relationship('App', backref='category', lazy=True)
    
    def __repr__(self):
        return f'<Category {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'description': self.description,
            'icon': self.icon,
            'color': self.color,
            'app_count': len(self.apps),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class App(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), unique=True, nullable=False)
    package_name = db.Column(db.String(200))
    version = db.Column(db.String(50), nullable=False)
    version_code = db.Column(db.Integer)
    developer = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    short_description = db.Column(db.String(500))
    
    # File information
    apk_url = db.Column(db.String(500), nullable=False)
    file_size = db.Column(db.String(20))  # e.g., "58.2 MB"
    file_size_bytes = db.Column(db.BigInteger)
    
    # App metadata
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    min_android = db.Column(db.String(20))  # e.g., "4.1"
    target_sdk = db.Column(db.Integer)
    permissions = db.Column(db.Text)  # JSON string of permissions
    
    # Ratings and downloads
    rating = db.Column(db.Float, default=0.0)
    rating_count = db.Column(db.Integer, default=0)
    download_count = db.Column(db.BigInteger, default=0)
    download_count_display = db.Column(db.String(20))  # e.g., "5B+"
    
    # Images and media
    icon_url = db.Column(db.String(500))
    screenshots = db.Column(db.Text)  # JSON string of screenshot URLs
    
    # SEO and content
    meta_title = db.Column(db.String(200))
    meta_description = db.Column(db.String(500))
    keywords = db.Column(db.String(500))
    changelog = db.Column(db.Text)
    features = db.Column(db.Text)  # JSON string of features
    
    # Status and moderation
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    is_featured = db.Column(db.Boolean, default=False)
    is_mod = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    published_at = db.Column(db.DateTime)
    
    # Relationships
    reviews = db.relationship('Review', backref='app', lazy=True, cascade='all, delete-orphan')
    downloads = db.relationship('Download', backref='app', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<App {self.name}>'
    
    def to_dict(self, include_reviews=False):
        data = {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'package_name': self.package_name,
            'version': self.version,
            'version_code': self.version_code,
            'developer': self.developer,
            'description': self.description,
            'short_description': self.short_description,
            'apk_url': self.apk_url,
            'file_size': self.file_size,
            'file_size_bytes': self.file_size_bytes,
            'category': self.category.to_dict() if self.category else None,
            'min_android': self.min_android,
            'target_sdk': self.target_sdk,
            'permissions': self.permissions,
            'rating': self.rating,
            'rating_count': self.rating_count,
            'download_count': self.download_count,
            'download_count_display': self.download_count_display,
            'icon_url': self.icon_url,
            'screenshots': self.screenshots,
            'meta_title': self.meta_title,
            'meta_description': self.meta_description,
            'keywords': self.keywords,
            'changelog': self.changelog,
            'features': self.features,
            'status': self.status,
            'is_featured': self.is_featured,
            'is_mod': self.is_mod,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'published_at': self.published_at.isoformat() if self.published_at else None
        }
        
        if include_reviews:
            data['reviews'] = [review.to_dict() for review in self.reviews]
            
        return data

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_id = db.Column(db.Integer, db.ForeignKey('app.id'), nullable=False)
    user_name = db.Column(db.String(100), nullable=False)
    user_email = db.Column(db.String(200))
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    title = db.Column(db.String(200))
    comment = db.Column(db.Text)
    helpful_count = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Review {self.user_name} - {self.rating} stars>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'app_id': self.app_id,
            'user_name': self.user_name,
            'rating': self.rating,
            'title': self.title,
            'comment': self.comment,
            'helpful_count': self.helpful_count,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Download(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_id = db.Column(db.Integer, db.ForeignKey('app.id'), nullable=False)
    ip_address = db.Column(db.String(45))  # IPv4 or IPv6
    user_agent = db.Column(db.String(500))
    country = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Download {self.app.name} - {self.created_at}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'app_id': self.app_id,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'country': self.country,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='admin')  # admin, moderator, editor
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Admin {self.username}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'is_active': self.is_active,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

