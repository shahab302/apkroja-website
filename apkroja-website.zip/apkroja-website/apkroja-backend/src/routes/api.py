from flask import Blueprint, request, jsonify
from datetime import datetime
import json
from src.models.user import db
from src.models.app import App, Category, Review, Download

api_bp = Blueprint('api', __name__)

# Public app routes
@api_bp.route('/apps', methods=['GET'])
def get_public_apps():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    category = request.args.get('category')
    search = request.args.get('search')
    featured = request.args.get('featured', type=bool)
    sort = request.args.get('sort', 'recent')  # recent, popular, rating
    
    query = App.query.filter_by(status='approved')
    
    if category:
        category_obj = Category.query.filter_by(slug=category).first()
        if category_obj:
            query = query.filter_by(category_id=category_obj.id)
    
    if search:
        query = query.filter(App.name.contains(search))
    
    if featured:
        query = query.filter_by(is_featured=True)
    
    # Sorting
    if sort == 'popular':
        query = query.order_by(App.download_count.desc())
    elif sort == 'rating':
        query = query.order_by(App.rating.desc())
    else:  # recent
        query = query.order_by(App.created_at.desc())
    
    apps = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'apps': [app.to_dict() for app in apps.items],
        'total': apps.total,
        'pages': apps.pages,
        'current_page': page,
        'per_page': per_page
    })

@api_bp.route('/apps/<slug>', methods=['GET'])
def get_app_by_slug(slug):
    app = App.query.filter_by(slug=slug, status='approved').first_or_404()
    return jsonify({
        'app': app.to_dict(include_reviews=True)
    })

@api_bp.route('/apps/featured', methods=['GET'])
def get_featured_apps():
    limit = request.args.get('limit', 10, type=int)
    apps = App.query.filter_by(status='approved', is_featured=True)\
                   .order_by(App.download_count.desc())\
                   .limit(limit).all()
    
    return jsonify({
        'apps': [app.to_dict() for app in apps]
    })

@api_bp.route('/apps/recent', methods=['GET'])
def get_recent_apps():
    limit = request.args.get('limit', 10, type=int)
    apps = App.query.filter_by(status='approved')\
                   .order_by(App.created_at.desc())\
                   .limit(limit).all()
    
    return jsonify({
        'apps': [app.to_dict() for app in apps]
    })

@api_bp.route('/apps/popular', methods=['GET'])
def get_popular_apps():
    limit = request.args.get('limit', 10, type=int)
    apps = App.query.filter_by(status='approved')\
                   .order_by(App.download_count.desc())\
                   .limit(limit).all()
    
    return jsonify({
        'apps': [app.to_dict() for app in apps]
    })

# Category routes
@api_bp.route('/categories', methods=['GET'])
def get_public_categories():
    categories = Category.query.order_by(Category.name).all()
    return jsonify({
        'categories': [category.to_dict() for category in categories]
    })

@api_bp.route('/categories/<slug>', methods=['GET'])
def get_category_by_slug(slug):
    category = Category.query.filter_by(slug=slug).first_or_404()
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    apps = App.query.filter_by(category_id=category.id, status='approved')\
                   .order_by(App.download_count.desc())\
                   .paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'category': category.to_dict(),
        'apps': [app.to_dict() for app in apps.items],
        'total': apps.total,
        'pages': apps.pages,
        'current_page': page
    })

# Search route
@api_bp.route('/search', methods=['GET'])
def search_apps():
    query = request.args.get('q', '').strip()
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    if not query:
        return jsonify({
            'apps': [],
            'total': 0,
            'pages': 0,
            'current_page': page,
            'query': query
        })
    
    apps = App.query.filter_by(status='approved')\
                   .filter(App.name.contains(query) | 
                          App.description.contains(query) |
                          App.developer.contains(query))\
                   .order_by(App.download_count.desc())\
                   .paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'apps': [app.to_dict() for app in apps.items],
        'total': apps.total,
        'pages': apps.pages,
        'current_page': page,
        'query': query
    })

# Download tracking
@api_bp.route('/apps/<slug>/download', methods=['POST'])
def track_download(slug):
    app = App.query.filter_by(slug=slug, status='approved').first_or_404()
    
    # Track download
    download = Download(
        app_id=app.id,
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent', ''),
        country=request.headers.get('CF-IPCountry', 'Unknown')  # Cloudflare header
    )
    
    # Increment download count
    app.download_count += 1
    
    db.session.add(download)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'download_url': app.apk_url,
        'file_size': app.file_size
    })

# Review routes
@api_bp.route('/apps/<slug>/reviews', methods=['GET'])
def get_app_reviews(slug):
    app = App.query.filter_by(slug=slug, status='approved').first_or_404()
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    reviews = Review.query.filter_by(app_id=app.id, status='approved')\
                         .order_by(Review.created_at.desc())\
                         .paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'reviews': [review.to_dict() for review in reviews.items],
        'total': reviews.total,
        'pages': reviews.pages,
        'current_page': page
    })

@api_bp.route('/apps/<slug>/reviews', methods=['POST'])
def submit_review(slug):
    app = App.query.filter_by(slug=slug, status='approved').first_or_404()
    data = request.get_json()
    
    review = Review(
        app_id=app.id,
        user_name=data['user_name'],
        user_email=data.get('user_email'),
        rating=data['rating'],
        title=data.get('title'),
        comment=data.get('comment'),
        status='pending'  # Requires admin approval
    )
    
    db.session.add(review)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Review submitted successfully. It will be published after moderation.',
        'review': review.to_dict()
    }), 201

@api_bp.route('/reviews/<int:review_id>/helpful', methods=['POST'])
def mark_review_helpful(review_id):
    review = Review.query.get_or_404(review_id)
    review.helpful_count += 1
    db.session.commit()
    
    return jsonify({
        'success': True,
        'helpful_count': review.helpful_count
    })

# Statistics for homepage
@api_bp.route('/stats', methods=['GET'])
def get_public_stats():
    total_apps = App.query.filter_by(status='approved').count()
    total_downloads = Download.query.count()
    
    return jsonify({
        'total_apps': total_apps,
        'total_downloads': total_downloads,
        'security_scan_rate': 100,
        'support_availability': '24/7'
    })

