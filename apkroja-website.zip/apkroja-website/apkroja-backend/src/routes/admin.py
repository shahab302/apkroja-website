from flask import Blueprint, request, jsonify, session
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime
import json
from src.models.user import db
from src.models.app import App, Category, Review, Download, Admin

admin_bp = Blueprint('admin', __name__)

# Authentication routes
@admin_bp.route('/auth/login', methods=['POST'])
def admin_login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    # For demo purposes, allow admin/admin login
    if username == 'admin' and password == 'admin':
        session['admin_id'] = 1
        session['admin_username'] = 'admin'
        return jsonify({
            'success': True,
            'message': 'Login successful',
            'admin': {
                'id': 1,
                'username': 'admin',
                'role': 'admin'
            }
        })
    
    # Check database for real admin users
    admin = Admin.query.filter_by(username=username).first()
    if admin and check_password_hash(admin.password_hash, password):
        admin.last_login = datetime.utcnow()
        db.session.commit()
        
        session['admin_id'] = admin.id
        session['admin_username'] = admin.username
        
        return jsonify({
            'success': True,
            'message': 'Login successful',
            'admin': admin.to_dict()
        })
    
    return jsonify({
        'success': False,
        'message': 'Invalid credentials'
    }), 401

@admin_bp.route('/auth/logout', methods=['POST'])
def admin_logout():
    session.clear()
    return jsonify({
        'success': True,
        'message': 'Logout successful'
    })

@admin_bp.route('/auth/check', methods=['GET'])
def check_auth():
    if 'admin_id' in session:
        return jsonify({
            'authenticated': True,
            'admin': {
                'id': session['admin_id'],
                'username': session['admin_username']
            }
        })
    return jsonify({'authenticated': False}), 401

# Dashboard stats
@admin_bp.route('/stats', methods=['GET'])
def get_stats():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    total_apps = App.query.count()
    total_downloads = Download.query.count()
    total_reviews = Review.query.count()
    pending_apps = App.query.filter_by(status='pending').count()
    
    # Recent downloads (last 24 hours)
    from datetime import datetime, timedelta
    yesterday = datetime.utcnow() - timedelta(days=1)
    recent_downloads = Download.query.filter(Download.created_at >= yesterday).count()
    
    return jsonify({
        'total_apps': total_apps,
        'total_downloads': total_downloads,
        'total_reviews': total_reviews,
        'pending_apps': pending_apps,
        'recent_downloads': recent_downloads,
        'security_scan_rate': 99.9
    })

# App management routes
@admin_bp.route('/apps', methods=['GET'])
def get_apps():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    category_id = request.args.get('category_id', type=int)
    search = request.args.get('search')
    
    query = App.query
    
    if status:
        query = query.filter_by(status=status)
    if category_id:
        query = query.filter_by(category_id=category_id)
    if search:
        query = query.filter(App.name.contains(search))
    
    query = query.order_by(App.created_at.desc())
    apps = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'apps': [app.to_dict() for app in apps.items],
        'total': apps.total,
        'pages': apps.pages,
        'current_page': page,
        'per_page': per_page
    })

@admin_bp.route('/apps', methods=['POST'])
def create_app():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    
    # Create slug from name
    import re
    slug = re.sub(r'[^a-zA-Z0-9\s-]', '', data['name'].lower())
    slug = re.sub(r'\s+', '-', slug).strip('-')
    
    app = App(
        name=data['name'],
        slug=slug,
        package_name=data.get('package_name'),
        version=data['version'],
        developer=data['developer'],
        description=data.get('description'),
        short_description=data.get('short_description'),
        apk_url=data['apk_url'],
        file_size=data.get('file_size'),
        category_id=data['category_id'],
        min_android=data.get('min_android'),
        permissions=json.dumps(data.get('permissions', [])),
        features=json.dumps(data.get('features', [])),
        status='pending'
    )
    
    db.session.add(app)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'App created successfully',
        'app': app.to_dict()
    }), 201

@admin_bp.route('/apps/<int:app_id>', methods=['PUT'])
def update_app(app_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    app = App.query.get_or_404(app_id)
    data = request.get_json()
    
    # Update fields
    for field in ['name', 'version', 'developer', 'description', 'short_description', 
                  'apk_url', 'file_size', 'category_id', 'min_android', 'status', 
                  'is_featured', 'is_mod']:
        if field in data:
            setattr(app, field, data[field])
    
    if 'permissions' in data:
        app.permissions = json.dumps(data['permissions'])
    if 'features' in data:
        app.features = json.dumps(data['features'])
    
    app.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'App updated successfully',
        'app': app.to_dict()
    })

@admin_bp.route('/apps/<int:app_id>', methods=['DELETE'])
def delete_app(app_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    app = App.query.get_or_404(app_id)
    db.session.delete(app)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'App deleted successfully'
    })

# Category management routes
@admin_bp.route('/categories', methods=['GET'])
def get_categories():
    categories = Category.query.order_by(Category.name).all()
    return jsonify({
        'categories': [category.to_dict() for category in categories]
    })

@admin_bp.route('/categories', methods=['POST'])
def create_category():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    
    # Create slug from name
    import re
    slug = re.sub(r'[^a-zA-Z0-9\s-]', '', data['name'].lower())
    slug = re.sub(r'\s+', '-', slug).strip('-')
    
    category = Category(
        name=data['name'],
        slug=slug,
        description=data.get('description'),
        icon=data.get('icon'),
        color=data.get('color')
    )
    
    db.session.add(category)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Category created successfully',
        'category': category.to_dict()
    }), 201

# Review management routes
@admin_bp.route('/reviews', methods=['GET'])
def get_reviews():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    
    query = Review.query
    if status:
        query = query.filter_by(status=status)
    
    query = query.order_by(Review.created_at.desc())
    reviews = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'reviews': [review.to_dict() for review in reviews.items],
        'total': reviews.total,
        'pages': reviews.pages,
        'current_page': page
    })

@admin_bp.route('/reviews/<int:review_id>/approve', methods=['POST'])
def approve_review(review_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    review = Review.query.get_or_404(review_id)
    review.status = 'approved'
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Review approved successfully'
    })

@admin_bp.route('/reviews/<int:review_id>/reject', methods=['POST'])
def reject_review(review_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    review = Review.query.get_or_404(review_id)
    review.status = 'rejected'
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Review rejected successfully'
    })

