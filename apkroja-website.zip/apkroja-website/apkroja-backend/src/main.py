import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.models.app import App, Category, Review, Download, Admin
from src.routes.user import user_bp
from src.routes.admin import admin_bp
from src.routes.api import api_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Enable CORS for all routes
CORS(app, supports_credentials=True)

# Register blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(admin_bp, url_prefix='/api/admin')
app.register_blueprint(api_bp, url_prefix='/api')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def create_sample_data():
    """Create sample data for testing"""
    # Create categories
    categories_data = [
        {'name': 'Communication', 'slug': 'communication', 'icon': 'MessageSquare', 'color': 'blue'},
        {'name': 'Social', 'slug': 'social', 'icon': 'Users', 'color': 'purple'},
        {'name': 'Entertainment', 'slug': 'entertainment', 'icon': 'Play', 'color': 'red'},
        {'name': 'Tools', 'slug': 'tools', 'icon': 'Settings', 'color': 'green'},
        {'name': 'Games', 'slug': 'games', 'icon': 'Gamepad2', 'color': 'orange'},
        {'name': 'Music', 'slug': 'music', 'icon': 'Music', 'color': 'pink'},
    ]
    
    for cat_data in categories_data:
        if not Category.query.filter_by(slug=cat_data['slug']).first():
            category = Category(**cat_data)
            db.session.add(category)
    
    db.session.commit()
    
    # Create sample apps
    comm_cat = Category.query.filter_by(slug='communication').first()
    social_cat = Category.query.filter_by(slug='social').first()
    ent_cat = Category.query.filter_by(slug='entertainment').first()
    music_cat = Category.query.filter_by(slug='music').first()
    tools_cat = Category.query.filter_by(slug='tools').first()
    
    apps_data = [
        {
            'name': 'WhatsApp Messenger',
            'slug': 'whatsapp-messenger',
            'version': '2.23.25.84',
            'developer': 'WhatsApp LLC',
            'description': 'WhatsApp Messenger is a FREE messaging app available for Android and other smartphones.',
            'short_description': 'Simple. Reliable. Private.',
            'apk_url': 'https://example.com/whatsapp.apk',
            'file_size': '58.2 MB',
            'category_id': comm_cat.id,
            'min_android': '4.1',
            'rating': 4.1,
            'rating_count': 125000000,
            'download_count': 5000000000,
            'download_count_display': '5B+',
            'status': 'approved',
            'is_featured': True
        },
        {
            'name': 'Instagram',
            'slug': 'instagram',
            'version': '302.0.0.23.114',
            'developer': 'Instagram',
            'description': 'Create and share your photos, stories, and videos with the friends and followers you care about.',
            'short_description': 'Create and share your photos, stories, and videos',
            'apk_url': 'https://example.com/instagram.apk',
            'file_size': '45.8 MB',
            'category_id': social_cat.id,
            'min_android': '5.0',
            'rating': 4.2,
            'rating_count': 18000000,
            'download_count': 1000000000,
            'download_count_display': '1B+',
            'status': 'approved',
            'is_featured': True
        },
        {
            'name': 'TikTok',
            'slug': 'tiktok',
            'version': '32.8.4',
            'developer': 'TikTok Pte. Ltd.',
            'description': 'TikTok is THE destination for mobile videos.',
            'short_description': 'Make your day',
            'apk_url': 'https://example.com/tiktok.apk',
            'file_size': '156.3 MB',
            'category_id': ent_cat.id,
            'min_android': '4.1',
            'rating': 4.4,
            'rating_count': 18000000,
            'download_count': 1000000000,
            'download_count_display': '1B+',
            'status': 'approved',
            'is_featured': True
        },
        {
            'name': 'Spotify Music',
            'slug': 'spotify-music',
            'version': '8.8.96.488',
            'developer': 'Spotify AB',
            'description': 'Spotify is a digital music service that gives you access to millions of songs.',
            'short_description': 'Music for everyone',
            'apk_url': 'https://example.com/spotify.apk',
            'file_size': '31.2 MB',
            'category_id': music_cat.id,
            'min_android': '5.0',
            'rating': 4.3,
            'rating_count': 8000000,
            'download_count': 1000000000,
            'download_count_display': '1B+',
            'status': 'approved'
        },
        {
            'name': 'YouTube',
            'slug': 'youtube',
            'version': '18.45.43',
            'developer': 'Google LLC',
            'description': 'Get the official YouTube app on Android phones and tablets.',
            'short_description': 'Watch, upload and share videos',
            'apk_url': 'https://example.com/youtube.apk',
            'file_size': '134.5 MB',
            'category_id': ent_cat.id,
            'min_android': '5.0',
            'rating': 4.1,
            'rating_count': 50000000,
            'download_count': 10000000000,
            'download_count_display': '10B+',
            'status': 'approved'
        },
        {
            'name': 'Google Chrome',
            'slug': 'google-chrome',
            'version': '119.0.6045.193',
            'developer': 'Google LLC',
            'description': 'Google Chrome is a fast, easy to use, and secure web browser.',
            'short_description': 'Fast, secure web browser',
            'apk_url': 'https://example.com/chrome.apk',
            'file_size': '156.8 MB',
            'category_id': tools_cat.id,
            'min_android': '7.0',
            'rating': 4.3,
            'rating_count': 25000000,
            'download_count': 10000000000,
            'download_count_display': '10B+',
            'status': 'approved'
        }
    ]
    
    for app_data in apps_data:
        if not App.query.filter_by(slug=app_data['slug']).first():
            app = App(**app_data)
            db.session.add(app)
    
    db.session.commit()

with app.app_context():
    db.create_all()
    create_sample_data()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
