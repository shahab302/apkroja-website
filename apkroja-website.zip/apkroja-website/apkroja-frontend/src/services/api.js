// API service for connecting frontend to backend
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://apkroja.com/api' 
  : 'http://localhost:5000/api'

class ApiService {
  constructor() {
    this.baseURL = API_BASE_URL
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      credentials: 'include', // Include cookies for session management
      ...options,
    }

    try {
      const response = await fetch(url, config)
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const contentType = response.headers.get('content-type')
      if (contentType && contentType.includes('application/json')) {
        return await response.json()
      }
      
      return await response.text()
    } catch (error) {
      console.error('API request failed:', error)
      throw error
    }
  }

  // Public API methods
  async getApps(params = {}) {
    const queryString = new URLSearchParams(params).toString()
    return this.request(`/apps${queryString ? `?${queryString}` : ''}`)
  }

  async getAppBySlug(slug) {
    return this.request(`/apps/${slug}`)
  }

  async getFeaturedApps(limit = 10) {
    return this.request(`/apps/featured?limit=${limit}`)
  }

  async getRecentApps(limit = 10) {
    return this.request(`/apps/recent?limit=${limit}`)
  }

  async getPopularApps(limit = 10) {
    return this.request(`/apps/popular?limit=${limit}`)
  }

  async getCategories() {
    return this.request('/categories')
  }

  async getCategoryBySlug(slug, params = {}) {
    const queryString = new URLSearchParams(params).toString()
    return this.request(`/categories/${slug}${queryString ? `?${queryString}` : ''}`)
  }

  async searchApps(query, params = {}) {
    const searchParams = new URLSearchParams({ q: query, ...params }).toString()
    return this.request(`/search?${searchParams}`)
  }

  async trackDownload(slug) {
    return this.request(`/apps/${slug}/download`, {
      method: 'POST'
    })
  }

  async getAppReviews(slug, params = {}) {
    const queryString = new URLSearchParams(params).toString()
    return this.request(`/apps/${slug}/reviews${queryString ? `?${queryString}` : ''}`)
  }

  async submitReview(slug, reviewData) {
    return this.request(`/apps/${slug}/reviews`, {
      method: 'POST',
      body: JSON.stringify(reviewData)
    })
  }

  async markReviewHelpful(reviewId) {
    return this.request(`/reviews/${reviewId}/helpful`, {
      method: 'POST'
    })
  }

  async getPublicStats() {
    return this.request('/stats')
  }

  // Admin API methods
  async adminLogin(credentials) {
    return this.request('/admin/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    })
  }

  async adminLogout() {
    return this.request('/admin/auth/logout', {
      method: 'POST'
    })
  }

  async checkAdminAuth() {
    return this.request('/admin/auth/check')
  }

  async getAdminStats() {
    return this.request('/admin/stats')
  }

  async getAdminApps(params = {}) {
    const queryString = new URLSearchParams(params).toString()
    return this.request(`/admin/apps${queryString ? `?${queryString}` : ''}`)
  }

  async createApp(appData) {
    return this.request('/admin/apps', {
      method: 'POST',
      body: JSON.stringify(appData)
    })
  }

  async updateApp(appId, appData) {
    return this.request(`/admin/apps/${appId}`, {
      method: 'PUT',
      body: JSON.stringify(appData)
    })
  }

  async deleteApp(appId) {
    return this.request(`/admin/apps/${appId}`, {
      method: 'DELETE'
    })
  }

  async getAdminCategories() {
    return this.request('/admin/categories')
  }

  async createCategory(categoryData) {
    return this.request('/admin/categories', {
      method: 'POST',
      body: JSON.stringify(categoryData)
    })
  }

  async getAdminReviews(params = {}) {
    const queryString = new URLSearchParams(params).toString()
    return this.request(`/admin/reviews${queryString ? `?${queryString}` : ''}`)
  }

  async approveReview(reviewId) {
    return this.request(`/admin/reviews/${reviewId}/approve`, {
      method: 'POST'
    })
  }

  async rejectReview(reviewId) {
    return this.request(`/admin/reviews/${reviewId}/reject`, {
      method: 'POST'
    })
  }
}

// Create and export a singleton instance
const apiService = new ApiService()
export default apiService

// Export individual methods for convenience
export const {
  getApps,
  getAppBySlug,
  getFeaturedApps,
  getRecentApps,
  getPopularApps,
  getCategories,
  getCategoryBySlug,
  searchApps,
  trackDownload,
  getAppReviews,
  submitReview,
  markReviewHelpful,
  getPublicStats,
  adminLogin,
  adminLogout,
  checkAdminAuth,
  getAdminStats,
  getAdminApps,
  createApp,
  updateApp,
  deleteApp,
  getAdminCategories,
  createCategory,
  getAdminReviews,
  approveReview,
  rejectReview
} = apiService

