import { Shield, Eye, Lock, Database, Cookie, Mail } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

const PrivacyPage = () => {
  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Privacy Policy</h1>
          <p className="text-xl text-muted-foreground">
            Your privacy is important to us. Learn how we collect, use, and protect your information.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Last updated: January 15, 2024
          </p>
        </div>

        {/* Quick Overview */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Eye className="w-5 h-5" />
              <span>Privacy at a Glance</span>
            </CardTitle>
            <CardDescription>
              Here's what you need to know about how we handle your data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Lock className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold mb-2">Secure Downloads</h3>
                <p className="text-sm text-muted-foreground">
                  All APK files are scanned and verified for safety
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Database className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold mb-2">Minimal Data</h3>
                <p className="text-sm text-muted-foreground">
                  We only collect essential information for service operation
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Cookie className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold mb-2">Cookie Control</h3>
                <p className="text-sm text-muted-foreground">
                  You can manage cookie preferences at any time
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="prose prose-lg max-w-none dark:prose-invert">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>1. Information We Collect</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Automatically Collected Information</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>IP address and general location information</li>
                  <li>Browser type and version</li>
                  <li>Device information (type, operating system)</li>
                  <li>Pages visited and time spent on our site</li>
                  <li>Referral source (how you found our website)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Information You Provide</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>Email address (if you contact us or subscribe to updates)</li>
                  <li>Comments and reviews you submit</li>
                  <li>Search queries and app preferences</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>2. How We Use Your Information</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">We use the collected information for the following purposes:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>To provide and maintain our APK download service</li>
                <li>To improve user experience and website functionality</li>
                <li>To analyze usage patterns and optimize our content</li>
                <li>To respond to user inquiries and provide customer support</li>
                <li>To detect and prevent fraudulent or malicious activity</li>
                <li>To comply with legal obligations and protect our rights</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>3. Cookies and Tracking Technologies</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>We use cookies and similar technologies to enhance your browsing experience:</p>
              <div>
                <h4 className="font-semibold mb-2">Essential Cookies</h4>
                <p className="text-muted-foreground mb-2">
                  Required for basic website functionality, including:
                </p>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>User preferences (dark mode, language settings)</li>
                  <li>Security and authentication</li>
                  <li>Load balancing and performance optimization</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Analytics Cookies</h4>
                <p className="text-muted-foreground">
                  Help us understand how visitors interact with our website through Google Analytics and similar services.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Advertising Cookies</h4>
                <p className="text-muted-foreground">
                  Used by Google AdSense and other advertising partners to show relevant ads based on your interests.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>4. Third-Party Services</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">We work with trusted third-party services that may collect information:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li><strong>Google AdSense:</strong> Displays advertisements on our website</li>
                <li><strong>Google Analytics:</strong> Provides website usage statistics</li>
                <li><strong>Cloudflare:</strong> Provides security and performance optimization</li>
                <li><strong>Content Delivery Networks (CDNs):</strong> Deliver APK files efficiently</li>
              </ul>
              <p className="mt-4 text-sm text-muted-foreground">
                These services have their own privacy policies, and we encourage you to review them.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>5. Data Security</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">We implement appropriate security measures to protect your information:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>SSL/TLS encryption for data transmission</li>
                <li>Regular security audits and vulnerability assessments</li>
                <li>Access controls and authentication systems</li>
                <li>Secure hosting infrastructure with reputable providers</li>
                <li>Regular backups and disaster recovery procedures</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>6. Your Rights and Choices</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">You have the following rights regarding your personal information:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li><strong>Access:</strong> Request information about data we have collected</li>
                <li><strong>Correction:</strong> Request correction of inaccurate information</li>
                <li><strong>Deletion:</strong> Request deletion of your personal data</li>
                <li><strong>Portability:</strong> Request a copy of your data in a portable format</li>
                <li><strong>Opt-out:</strong> Unsubscribe from marketing communications</li>
                <li><strong>Cookie Control:</strong> Manage cookie preferences in your browser</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>7. Children's Privacy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Our service is not intended for children under 13 years of age. We do not knowingly collect 
                personal information from children under 13. If you are a parent or guardian and believe 
                your child has provided us with personal information, please contact us immediately.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>8. International Data Transfers</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Your information may be transferred to and processed in countries other than your own. 
                We ensure appropriate safeguards are in place to protect your data in accordance with 
                applicable privacy laws and regulations.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>9. Changes to This Policy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We may update this Privacy Policy from time to time. We will notify you of any changes 
                by posting the new Privacy Policy on this page and updating the "Last updated" date. 
                We encourage you to review this Privacy Policy periodically.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Mail className="w-5 h-5" />
                <span>10. Contact Us</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                If you have any questions about this Privacy Policy or our data practices, please contact us:
              </p>
              <div className="bg-muted/50 rounded-lg p-4">
                <p><strong>Email:</strong> privacy@apkroja.com</p>
                <p><strong>Website:</strong> https://apkroja.com/contact</p>
                <p><strong>Response Time:</strong> We aim to respond within 48 hours</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default PrivacyPage

