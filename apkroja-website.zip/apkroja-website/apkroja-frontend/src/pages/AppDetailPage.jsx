import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Download, Star, Users, Smartphone, Calendar, Shield, Info, MessageSquare, ThumbsUp, Share2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import AdBanner from '../components/AdBanner'

const AppDetailPage = () => {
  const { slug } = useParams()
  const [app, setApp] = useState(null)
  const [screenshots, setScreenshots] = useState([])
  const [reviews, setReviews] = useState([])
  const [relatedApps, setRelatedApps] = useState([])

  useEffect(() => {
    // Mock app data - Replace with actual API call
    setApp({
      id: 1,
      name: 'WhatsApp Messenger',
      slug: 'whatsapp-messenger',
      version: '2.23.25.84',
      size: '58.2 MB',
      downloads: '5B+',
      rating: 4.1,
      totalRatings: '125M',
      icon: '/api/placeholder/120/120',
      category: 'Communication',
      description: 'WhatsApp Messenger is a FREE messaging app available for Android and other smartphones. WhatsApp uses your phone\'s Internet connection (4G/3G/2G/EDGE or Wi-Fi, as available) to message and call friends and family.',
      longDescription: `WhatsApp Messenger is a cross-platform mobile messaging app which allows you to exchange messages without having to pay for SMS. WhatsApp Messenger is available for iPhone, BlackBerry, Android, Windows Phone and Nokia and yes, those phones can all message each other!

Because WhatsApp Messenger uses the same internet data plan that you use for email and web browsing, there is no cost to message and stay in touch with your friends.

In addition to basic messaging WhatsApp users can create groups, send each other unlimited images, video and audio media messages.`,
      developer: 'WhatsApp LLC',
      lastUpdated: '2024-01-15',
      minAndroid: '4.1',
      downloadUrl: 'https://example.com/whatsapp.apk',
      features: [
        'End-to-end encryption for all messages',
        'Voice and video calls',
        'Group chats with up to 1024 participants',
        'Status updates that disappear after 24 hours',
        'Document sharing (PDF, documents, spreadsheets)',
        'Location sharing',
        'Contact sharing',
        'Voice messages',
        'Photo and video sharing'
      ],
      permissions: [
        'Camera - to take photos and videos',
        'Microphone - to record voice messages and make calls',
        'Storage - to save media files',
        'Contacts - to find friends using WhatsApp',
        'Location - to share your location',
        'Phone - to verify your phone number'
      ],
      changelog: [
        'Bug fixes and performance improvements',
        'Enhanced security features',
        'Improved call quality',
        'New emoji reactions',
        'Better group management tools'
      ]
    })

    setScreenshots([
      '/api/placeholder/300/600',
      '/api/placeholder/300/600',
      '/api/placeholder/300/600',
      '/api/placeholder/300/600'
    ])

    setReviews([
      {
        id: 1,
        user: 'John D.',
        rating: 5,
        comment: 'Great app! Works perfectly and very reliable.',
        date: '2024-01-10'
      },
      {
        id: 2,
        user: 'Sarah M.',
        rating: 4,
        comment: 'Good messaging app, but could use more customization options.',
        date: '2024-01-08'
      },
      {
        id: 3,
        user: 'Mike R.',
        rating: 5,
        comment: 'Essential app for communication. Love the end-to-end encryption.',
        date: '2024-01-05'
      }
    ])

    setRelatedApps([
      {
        id: 2,
        name: 'Telegram',
        slug: 'telegram',
        icon: '/api/placeholder/60/60',
        rating: 4.3,
        downloads: '1B+'
      },
      {
        id: 3,
        name: 'Signal',
        slug: 'signal',
        icon: '/api/placeholder/60/60',
        rating: 4.5,
        downloads: '100M+'
      }
    ])
  }, [slug])

  if (!app) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading app details...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-muted-foreground">
            <li><Link to="/" className="hover:text-foreground">Home</Link></li>
            <li>/</li>
            <li><Link to={`/category/${app.category.toLowerCase()}`} className="hover:text-foreground">{app.category}</Link></li>
            <li>/</li>
            <li className="text-foreground">{app.name}</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* App Header */}
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-start space-y-4 md:space-y-0 md:space-x-6">
                  <div className="w-32 h-32 rounded-xl bg-muted flex items-center justify-center overflow-hidden">
                    <Smartphone className="w-16 h-16 text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold mb-2">{app.name}</h1>
                    <p className="text-muted-foreground mb-4">{app.description}</p>
                    <div className="flex flex-wrap items-center gap-4 mb-4">
                      <div className="flex items-center space-x-1">
                        <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                        <span className="font-semibold">{app.rating}</span>
                        <span className="text-muted-foreground">({app.totalRatings})</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="w-5 h-5 text-muted-foreground" />
                        <span>{app.downloads} downloads</span>
                      </div>
                      <Badge variant="secondary">{app.category}</Badge>
                    </div>
                    <div className="flex flex-wrap gap-3">
                      <Link to={`/download/${app.slug}`}>
                        <Button size="lg" className="px-8">
                          <Download className="w-5 h-5 mr-2" />
                          Download APK
                        </Button>
                      </Link>
                      <Button variant="outline" size="lg">
                        <Share2 className="w-5 h-5 mr-2" />
                        Share
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Screenshots */}
            <Card>
              <CardHeader>
                <CardTitle>Screenshots</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {screenshots.map((screenshot, index) => (
                    <div key={index} className="aspect-[9/16] bg-muted rounded-lg overflow-hidden">
                      <div className="w-full h-full bg-gradient-to-br from-muted to-muted-foreground/20 flex items-center justify-center">
                        <Smartphone className="w-8 h-8 text-muted-foreground" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Ad Banner */}
            <AdBanner position="content" />

            {/* Detailed Information */}
            <Card>
              <CardContent className="p-0">
                <Tabs defaultValue="description" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="description">Description</TabsTrigger>
                    <TabsTrigger value="features">Features</TabsTrigger>
                    <TabsTrigger value="permissions">Permissions</TabsTrigger>
                    <TabsTrigger value="changelog">What's New</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="description" className="p-6">
                    <div className="prose prose-sm max-w-none dark:prose-invert">
                      <p className="whitespace-pre-line">{app.longDescription}</p>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="features" className="p-6">
                    <ul className="space-y-3">
                      {app.features.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-3">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </TabsContent>
                  
                  <TabsContent value="permissions" className="p-6">
                    <div className="space-y-4">
                      <div className="bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                        <div className="flex items-start space-x-3">
                          <Info className="w-5 h-5 text-yellow-600 mt-0.5" />
                          <div>
                            <h4 className="font-medium text-yellow-900 dark:text-yellow-100 mb-1">
                              App Permissions
                            </h4>
                            <p className="text-sm text-yellow-700 dark:text-yellow-300">
                              This app requires the following permissions to function properly:
                            </p>
                          </div>
                        </div>
                      </div>
                      <ul className="space-y-3">
                        {app.permissions.map((permission, index) => (
                          <li key={index} className="flex items-start space-x-3">
                            <Shield className="w-4 h-4 text-muted-foreground mt-1" />
                            <span className="text-sm">{permission}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="changelog" className="p-6">
                    <div className="space-y-2">
                      <h4 className="font-semibold mb-3">Version {app.version}</h4>
                      <ul className="space-y-2">
                        {app.changelog.map((change, index) => (
                          <li key={index} className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                            <span className="text-sm">{change}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Reviews */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageSquare className="w-5 h-5" />
                  <span>User Reviews</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {reviews.map((review) => (
                  <div key={review.id} className="border-b pb-4 last:border-b-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{review.user}</span>
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating
                                  ? 'fill-yellow-400 text-yellow-400'
                                  : 'text-muted-foreground'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <span className="text-sm text-muted-foreground">{review.date}</span>
                    </div>
                    <p className="text-sm">{review.comment}</p>
                    <div className="flex items-center space-x-4 mt-2">
                      <Button variant="ghost" size="sm">
                        <ThumbsUp className="w-4 h-4 mr-1" />
                        Helpful
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Ad Banner */}
            <AdBanner position="sidebar" />

            {/* App Info */}
            <Card>
              <CardHeader>
                <CardTitle>App Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Version</span>
                  <span>{app.version}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Size</span>
                  <span>{app.size}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Developer</span>
                  <span>{app.developer}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Category</span>
                  <span>{app.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Min Android</span>
                  <span>{app.minAndroid}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Updated</span>
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{app.lastUpdated}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Related Apps */}
            <Card>
              <CardHeader>
                <CardTitle>Related Apps</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {relatedApps.map((relatedApp) => (
                  <Link key={relatedApp.id} to={`/apps/${relatedApp.slug}`}>
                    <div className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted transition-colors">
                      <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                        <Smartphone className="w-6 h-6 text-muted-foreground" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{relatedApp.name}</h4>
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                          <span>{relatedApp.rating}</span>
                          <span>•</span>
                          <span>{relatedApp.downloads}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AppDetailPage

