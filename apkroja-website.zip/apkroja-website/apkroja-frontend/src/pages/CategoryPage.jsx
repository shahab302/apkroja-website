import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Download, Star, Users, Smartphone, Filter, Grid, List } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import AdBanner from '../components/AdBanner'

const CategoryPage = () => {
  const { category } = useParams()
  const [apps, setApps] = useState([])
  const [loading, setLoading] = useState(true)
  const [sortBy, setSortBy] = useState('popular')
  const [viewMode, setViewMode] = useState('grid')
  const [currentPage, setCurrentPage] = useState(1)
  const appsPerPage = 12

  useEffect(() => {
    // Mock data - Replace with actual API call
    setLoading(true)
    setTimeout(() => {
      const mockApps = [
        {
          id: 1,
          name: 'WhatsApp Messenger',
          slug: 'whatsapp-messenger',
          version: '2.23.25.84',
          size: '58.2 MB',
          downloads: '5B+',
          rating: 4.1,
          icon: '/api/placeholder/80/80',
          category: 'Communication',
          description: 'Simple. Reliable. Private.'
        },
        {
          id: 2,
          name: 'Instagram',
          slug: 'instagram',
          version: '302.0.0.23.114',
          size: '45.8 MB',
          downloads: '1B+',
          rating: 4.2,
          icon: '/api/placeholder/80/80',
          category: 'Social',
          description: 'Create and share your photos, stories, and videos'
        },
        {
          id: 3,
          name: 'TikTok',
          slug: 'tiktok',
          version: '32.8.4',
          size: '156.3 MB',
          downloads: '1B+',
          rating: 4.4,
          icon: '/api/placeholder/80/80',
          category: 'Entertainment',
          description: 'Make your day'
        },
        {
          id: 4,
          name: 'Spotify Music',
          slug: 'spotify-music',
          version: '8.8.96.488',
          size: '31.2 MB',
          downloads: '1B+',
          rating: 4.3,
          icon: '/api/placeholder/80/80',
          category: 'Music',
          description: 'Music for everyone'
        },
        {
          id: 5,
          name: 'Netflix',
          slug: 'netflix',
          version: '8.89.0',
          size: '45.1 MB',
          downloads: '1B+',
          rating: 4.2,
          icon: '/api/placeholder/80/80',
          category: 'Entertainment',
          description: 'Watch TV shows & movies'
        },
        {
          id: 6,
          name: 'YouTube',
          slug: 'youtube',
          version: '18.45.43',
          size: '134.5 MB',
          downloads: '10B+',
          rating: 4.1,
          icon: '/api/placeholder/80/80',
          category: 'Video',
          description: 'Watch, upload and share videos'
        }
      ]
      setApps(mockApps)
      setLoading(false)
    }, 1000)
  }, [category, sortBy])

  const getCategoryTitle = () => {
    switch (category) {
      case 'games':
        return 'Games'
      case 'apps':
        return 'Apps'
      case 'tools':
        return 'Tools'
      default:
        return 'All Apps'
    }
  }

  const getCategoryDescription = () => {
    switch (category) {
      case 'games':
        return 'Discover the best Android games for entertainment and fun'
      case 'apps':
        return 'Find useful Android applications for productivity and daily use'
      case 'tools':
        return 'Essential tools and utilities for your Android device'
      default:
        return 'Browse all available Android apps and games'
    }
  }

  const AppCard = ({ app }) => (
    <Card className="group hover:shadow-lg transition-all duration-300">
      <CardContent className="p-4">
        <div className={`flex ${viewMode === 'list' ? 'items-center space-x-4' : 'flex-col items-center text-center'}`}>
          <div className={`${viewMode === 'list' ? 'w-16 h-16' : 'w-20 h-20 mb-3'} rounded-xl bg-muted flex items-center justify-center overflow-hidden`}>
            <Smartphone className={`${viewMode === 'list' ? 'w-8 h-8' : 'w-10 h-10'} text-muted-foreground`} />
          </div>
          <div className={`${viewMode === 'list' ? 'flex-1' : 'w-full'}`}>
            <h3 className={`font-semibold group-hover:text-primary transition-colors mb-1 ${viewMode === 'list' ? 'text-base' : 'text-lg'}`}>
              {app.name}
            </h3>
            <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{app.description}</p>
            <div className={`flex ${viewMode === 'list' ? 'items-center space-x-4' : 'items-center justify-center space-x-2'} text-xs text-muted-foreground mb-3`}>
              <div className="flex items-center space-x-1">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span>{app.rating}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Users className="w-3 h-3" />
                <span>{app.downloads}</span>
              </div>
              <span>{app.size}</span>
            </div>
            <div className={`flex ${viewMode === 'list' ? 'items-center justify-between' : 'items-center justify-center space-x-2'}`}>
              <Badge variant="secondary" className="text-xs">
                v{app.version}
              </Badge>
              <Link to={`/apps/${app.slug}`}>
                <Button size="sm" className="h-8">
                  <Download className="w-3 h-3 mr-1" />
                  Download
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const totalPages = Math.ceil(apps.length / appsPerPage)
  const startIndex = (currentPage - 1) * appsPerPage
  const endIndex = startIndex + appsPerPage
  const currentApps = apps.slice(startIndex, endIndex)

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-muted-foreground">
            <li><Link to="/" className="hover:text-foreground">Home</Link></li>
            <li>/</li>
            <li className="text-foreground">{getCategoryTitle()}</li>
          </ol>
        </nav>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">{getCategoryTitle()}</h1>
          <p className="text-xl text-muted-foreground">{getCategoryDescription()}</p>
        </div>

        {/* Ad Banner */}
        <div className="mb-8">
          <AdBanner position="content" />
        </div>

        {/* Filters and Controls */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0 mb-8">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4" />
              <span className="text-sm font-medium">Sort by:</span>
            </div>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="name">Name A-Z</SelectItem>
                <SelectItem value="size">Smallest Size</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Apps Grid/List */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-20 h-20 bg-muted rounded-xl mb-3"></div>
                    <div className="w-32 h-4 bg-muted rounded mb-2"></div>
                    <div className="w-24 h-3 bg-muted rounded mb-3"></div>
                    <div className="w-20 h-8 bg-muted rounded"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
                : 'grid-cols-1'
            }`}>
              {currentApps.map((app) => (
                <AppCard key={app.id} app={app} />
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center space-x-2 mt-12">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                
                {[...Array(totalPages)].map((_, i) => {
                  const page = i + 1
                  if (
                    page === 1 ||
                    page === totalPages ||
                    (page >= currentPage - 1 && page <= currentPage + 1)
                  ) {
                    return (
                      <Button
                        key={page}
                        variant={currentPage === page ? 'default' : 'outline'}
                        onClick={() => setCurrentPage(page)}
                        className="w-10"
                      >
                        {page}
                      </Button>
                    )
                  } else if (page === currentPage - 2 || page === currentPage + 2) {
                    return <span key={page} className="px-2">...</span>
                  }
                  return null
                })}
                
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>
              </div>
            )}
          </>
        )}

        {/* Results Info */}
        <div className="text-center text-muted-foreground mt-8">
          <p>
            Showing {startIndex + 1}-{Math.min(endIndex, apps.length)} of {apps.length} apps
          </p>
        </div>
      </div>
    </div>
  )
}

export default CategoryPage

