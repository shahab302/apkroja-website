import { useState, useEffect } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { Search, Download, Star, Users, Smartphone, Filter, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import AdBanner from '../components/AdBanner'

const SearchPage = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '')
  const [searchResults, setSearchResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [filters, setFilters] = useState({
    category: '',
    rating: '',
    size: ''
  })

  useEffect(() => {
    const query = searchParams.get('q')
    if (query) {
      setSearchQuery(query)
      performSearch(query)
    }
  }, [searchParams])

  const performSearch = async (query) => {
    if (!query.trim()) return

    setLoading(true)
    
    // Mock search results - Replace with actual API call
    setTimeout(() => {
      const mockResults = [
        {
          id: 1,
          name: 'WhatsApp Messenger',
          slug: 'whatsapp-messenger',
          version: '2.23.25.84',
          size: '58.2 MB',
          downloads: '5B+',
          rating: 4.1,
          icon: '/api/placeholder/80/80',
          category: 'Communication',
          description: 'Simple. Reliable. Private messaging app.',
          relevance: 95
        },
        {
          id: 2,
          name: 'Instagram',
          slug: 'instagram',
          version: '302.0.0.23.114',
          size: '45.8 MB',
          downloads: '1B+',
          rating: 4.2,
          icon: '/api/placeholder/80/80',
          category: 'Social',
          description: 'Create and share your photos, stories, and videos with friends.',
          relevance: 88
        },
        {
          id: 3,
          name: 'Spotify Music',
          slug: 'spotify-music',
          version: '8.8.96.488',
          size: '31.2 MB',
          downloads: '1B+',
          rating: 4.3,
          icon: '/api/placeholder/80/80',
          category: 'Music',
          description: 'Music streaming service with millions of songs.',
          relevance: 75
        }
      ].filter(app => 
        app.name.toLowerCase().includes(query.toLowerCase()) ||
        app.description.toLowerCase().includes(query.toLowerCase()) ||
        app.category.toLowerCase().includes(query.toLowerCase())
      )

      setSearchResults(mockResults)
      setLoading(false)
    }, 800)
  }

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery.trim() })
    }
  }

  const clearFilters = () => {
    setFilters({
      category: '',
      rating: '',
      size: ''
    })
  }

  const hasActiveFilters = Object.values(filters).some(filter => filter !== '')

  const SearchResultCard = ({ app }) => (
    <Card className="group hover:shadow-lg transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex items-start space-x-4">
          <div className="w-16 h-16 rounded-xl bg-muted flex items-center justify-center overflow-hidden">
            <Smartphone className="w-8 h-8 text-muted-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-semibold text-lg group-hover:text-primary transition-colors mb-1">
                  {app.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                  {app.description}
                </p>
                <div className="flex items-center space-x-4 text-xs text-muted-foreground mb-3">
                  <div className="flex items-center space-x-1">
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    <span>{app.rating}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-3 h-3" />
                    <span>{app.downloads}</span>
                  </div>
                  <span>{app.size}</span>
                  <Badge variant="outline" className="text-xs">
                    {app.category}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <Badge variant="secondary" className="text-xs">
                    v{app.version}
                  </Badge>
                  <div className="flex items-center space-x-2">
                    <Link to={`/apps/${app.slug}`}>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </Link>
                    <Link to={`/download/${app.slug}`}>
                      <Button size="sm">
                        <Download className="w-3 h-3 mr-1" />
                        Download
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Search Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">Search Apps</h1>
          <p className="text-xl text-muted-foreground mb-6">
            Find your favorite Android apps and games
          </p>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="relative max-w-2xl">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search for apps, games, or categories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 h-12 text-lg"
            />
            <Button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2">
              Search
            </Button>
          </form>
        </div>

        {/* Ad Banner */}
        <div className="mb-8">
          <AdBanner position="content" />
        </div>

        {/* Search Results */}
        {searchParams.get('q') && (
          <div>
            {/* Results Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-semibold mb-2">
                  Search Results for "{searchParams.get('q')}"
                </h2>
                {!loading && (
                  <p className="text-muted-foreground">
                    {searchResults.length} {searchResults.length === 1 ? 'result' : 'results'} found
                  </p>
                )}
              </div>

              {/* Filters */}
              <div className="flex items-center space-x-4">
                {hasActiveFilters && (
                  <Button variant="outline" size="sm" onClick={clearFilters}>
                    <X className="w-4 h-4 mr-1" />
                    Clear Filters
                  </Button>
                )}
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-1" />
                  Filters
                </Button>
              </div>
            </div>

            {/* Loading State */}
            {loading && (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-4">
                        <div className="w-16 h-16 bg-muted rounded-xl"></div>
                        <div className="flex-1 space-y-2">
                          <div className="w-48 h-4 bg-muted rounded"></div>
                          <div className="w-full h-3 bg-muted rounded"></div>
                          <div className="w-32 h-3 bg-muted rounded"></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Search Results */}
            {!loading && searchResults.length > 0 && (
              <div className="space-y-4">
                {searchResults.map((app) => (
                  <SearchResultCard key={app.id} app={app} />
                ))}
              </div>
            )}

            {/* No Results */}
            {!loading && searchResults.length === 0 && searchParams.get('q') && (
              <div className="text-center py-12">
                <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-12 h-12 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">No results found</h3>
                <p className="text-muted-foreground mb-6">
                  We couldn't find any apps matching "{searchParams.get('q')}". 
                  Try different keywords or browse our categories.
                </p>
                <div className="flex justify-center space-x-4">
                  <Link to="/category/games">
                    <Button variant="outline">Browse Games</Button>
                  </Link>
                  <Link to="/category/apps">
                    <Button variant="outline">Browse Apps</Button>
                  </Link>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Popular Searches */}
        {!searchParams.get('q') && (
          <div className="mt-12">
            <h2 className="text-2xl font-semibold mb-6">Popular Searches</h2>
            <div className="flex flex-wrap gap-2">
              {[
                'WhatsApp', 'Instagram', 'TikTok', 'YouTube', 'Spotify', 
                'Netflix', 'Facebook', 'Telegram', 'Chrome', 'Games'
              ].map((term) => (
                <Button
                  key={term}
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSearchQuery(term)
                    setSearchParams({ q: term })
                  }}
                >
                  {term}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Search Tips */}
        {!searchParams.get('q') && (
          <div className="mt-12 bg-muted/30 rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Search Tips</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Use specific app names for better results</li>
              <li>• Try searching by category (games, social, productivity)</li>
              <li>• Use keywords related to app functionality</li>
              <li>• Check spelling and try alternative terms</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}

export default SearchPage

