import { Info, Shield, Users, Zap, Heart, Target, Award, Globe } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

const AboutPage = () => {
  const stats = [
    { icon: Users, label: 'Active Users', value: '1M+' },
    { icon: Globe, label: 'Countries Served', value: '150+' },
    { icon: Award, label: 'Apps Available', value: '50K+' },
    { icon: Shield, label: 'Security Scans', value: '100%' }
  ]

  const values = [
    {
      icon: Shield,
      title: 'Security First',
      description: 'Every APK file is thoroughly scanned for malware and security threats before being made available for download.'
    },
    {
      icon: Zap,
      title: 'Fast & Reliable',
      description: 'Our high-speed servers ensure quick downloads with minimal wait times and maximum reliability.'
    },
    {
      icon: Users,
      title: 'User-Focused',
      description: 'We prioritize user experience with clean design, easy navigation, and helpful features.'
    },
    {
      icon: Heart,
      title: 'Community Driven',
      description: 'Built for the Android community, by people who understand what users really need.'
    }
  ]

  const team = [
    {
      name: 'Alex Johnson',
      role: 'Founder & CEO',
      description: 'Passionate about making Android apps accessible to everyone worldwide.'
    },
    {
      name: 'Sarah Chen',
      role: 'Head of Security',
      description: 'Ensures all APK files meet our strict security and safety standards.'
    },
    {
      name: 'Mike Rodriguez',
      role: 'Lead Developer',
      description: 'Builds and maintains our fast, reliable download infrastructure.'
    },
    {
      name: 'Emma Wilson',
      role: 'Community Manager',
      description: 'Connects with users and ensures the best possible experience.'
    }
  ]

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <Info className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">About APKRoja</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            We're on a mission to make Android apps accessible to everyone, everywhere. 
            APKRoja provides safe, fast, and free APK downloads for millions of users worldwide.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="text-2xl font-bold mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Our Story */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="text-2xl">Our Story</CardTitle>
            <CardDescription>How APKRoja came to be</CardDescription>
          </CardHeader>
          <CardContent className="prose prose-lg max-w-none dark:prose-invert">
            <p>
              APKRoja was founded in 2020 with a simple vision: to create the most reliable and user-friendly 
              platform for downloading Android APK files. We noticed that many existing platforms were cluttered 
              with ads, had slow download speeds, or lacked proper security measures.
            </p>
            <p>
              Our team of Android enthusiasts and security experts came together to build something better. 
              We wanted to create a platform that prioritizes user experience, security, and accessibility 
              above all else.
            </p>
            <p>
              Today, APKRoja serves millions of users across 150+ countries, providing access to over 50,000 
              Android applications. We continue to grow and improve, always keeping our users' needs at the 
              center of everything we do.
            </p>
          </CardContent>
        </Card>

        {/* Our Values */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Values</h2>
            <p className="text-xl text-muted-foreground">
              The principles that guide everything we do
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <value.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                      <p className="text-muted-foreground">{value.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-5 h-5" />
                <span>Our Mission</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                To provide the world's most trusted platform for downloading Android APK files, 
                ensuring every user has safe, fast, and free access to the apps they need.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Globe className="w-5 h-5" />
                <span>Our Vision</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                A world where everyone has equal access to mobile technology, regardless of their 
                location, device, or economic situation.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Team */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
            <p className="text-xl text-muted-foreground">
              The people behind APKRoja
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, index) => (
              <Card key={index}>
                <CardContent className="p-6 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-10 h-10 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg mb-1">{member.name}</h3>
                  <p className="text-primary text-sm mb-3">{member.role}</p>
                  <p className="text-muted-foreground text-sm">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Security & Trust */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-5 h-5" />
              <span>Security & Trust</span>
            </CardTitle>
            <CardDescription>
              How we keep you safe
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Shield className="w-6 h-6 text-green-600" />
                </div>
                <h4 className="font-semibold mb-2">Malware Scanning</h4>
                <p className="text-sm text-muted-foreground">
                  Every APK is scanned with multiple antivirus engines before publication
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Award className="w-6 h-6 text-blue-600" />
                </div>
                <h4 className="font-semibold mb-2">Verified Sources</h4>
                <p className="text-sm text-muted-foreground">
                  We only host APKs from trusted developers and official sources
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-purple-600" />
                </div>
                <h4 className="font-semibold mb-2">Regular Updates</h4>
                <p className="text-sm text-muted-foreground">
                  Our security systems are continuously updated to detect new threats
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact CTA */}
        <Card className="text-center">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-4">Get in Touch</h2>
            <p className="text-muted-foreground mb-6">
              Have questions, suggestions, or just want to say hello? We'd love to hear from you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/contact" className="inline-flex items-center justify-center rounded-md bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors">
                Contact Us
              </a>
              <a href="mailto:hello@apkroja.com" className="inline-flex items-center justify-center rounded-md border border-input bg-background px-6 py-3 text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors">
                Email Us
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default AboutPage

