import { FileText, Scale, Shield, AlertTriangle, CheckCircle, Mail } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

const TermsPage = () => {
  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <FileText className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Terms of Service</h1>
          <p className="text-xl text-muted-foreground">
            Please read these terms carefully before using our APK download service.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Last updated: January 15, 2024
          </p>
        </div>

        {/* Quick Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Scale className="w-5 h-5" />
              <span>Terms Summary</span>
            </CardTitle>
            <CardDescription>
              Key points about using APKRoja
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Free Service</h4>
                    <p className="text-sm text-muted-foreground">
                      APKRoja is completely free to use
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Safe Downloads</h4>
                    <p className="text-sm text-muted-foreground">
                      All APKs are scanned for malware
                    </p>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Use at Your Own Risk</h4>
                    <p className="text-sm text-muted-foreground">
                      Install APKs responsibly on your device
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Respect Copyrights</h4>
                    <p className="text-sm text-muted-foreground">
                      Only download apps you have rights to use
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="prose prose-lg max-w-none dark:prose-invert">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>1. Acceptance of Terms</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                By accessing and using APKRoja ("the Service"), you accept and agree to be bound by the terms 
                and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
              </p>
              <p className="text-muted-foreground mt-4">
                These Terms of Service ("Terms") govern your use of our website located at apkroja.com 
                (the "Service") operated by APKRoja ("us", "we", or "our").
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>2. Description of Service</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">APKRoja provides the following services:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Free download of Android APK files</li>
                <li>App information, descriptions, and screenshots</li>
                <li>User reviews and ratings</li>
                <li>Search and categorization of apps</li>
                <li>Security scanning of APK files</li>
              </ul>
              <p className="mt-4 text-muted-foreground">
                We reserve the right to modify, suspend, or discontinue any part of the Service at any time 
                without prior notice.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>3. User Responsibilities</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">As a user of APKRoja, you agree to:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Use the Service only for lawful purposes</li>
                <li>Not attempt to gain unauthorized access to our systems</li>
                <li>Not distribute malware or harmful content</li>
                <li>Respect intellectual property rights of app developers</li>
                <li>Not use automated tools to scrape or download content in bulk</li>
                <li>Provide accurate information when submitting reviews or comments</li>
                <li>Not engage in any activity that could harm or disrupt the Service</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>4. APK Downloads and Installation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Download Responsibility</h4>
                <p className="text-muted-foreground">
                  You download and install APK files at your own risk. While we scan all files for malware, 
                  we cannot guarantee that all APKs are completely safe or will work perfectly on your device.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Device Compatibility</h4>
                <p className="text-muted-foreground">
                  APK files may not be compatible with all Android devices or versions. Check compatibility 
                  requirements before downloading.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Security Settings</h4>
                <p className="text-muted-foreground">
                  Installing APKs requires enabling "Unknown sources" in your Android settings. This may 
                  expose your device to security risks from other sources.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>5. Intellectual Property</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-muted-foreground">
                All APK files, app information, and related content are the property of their respective 
                developers and publishers. APKRoja does not claim ownership of any third-party applications.
              </p>
              <p className="mb-4 text-muted-foreground">
                The APKRoja website design, logo, and original content are protected by copyright and 
                other intellectual property laws. You may not reproduce, distribute, or create derivative 
                works without our express written permission.
              </p>
              <p className="text-muted-foreground">
                If you believe your intellectual property rights have been violated, please contact us 
                immediately with details of the alleged infringement.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>6. Privacy and Data Collection</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Your privacy is important to us. Our collection and use of personal information is governed 
                by our Privacy Policy, which is incorporated into these Terms by reference. Please review 
                our Privacy Policy to understand our practices.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>7. Disclaimers and Limitations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Service Availability</h4>
                <p className="text-muted-foreground">
                  We strive to maintain high availability but cannot guarantee uninterrupted service. 
                  The Service may be temporarily unavailable due to maintenance, updates, or technical issues.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Content Accuracy</h4>
                <p className="text-muted-foreground">
                  While we make efforts to ensure accuracy, we do not warrant that app descriptions, 
                  screenshots, or other content is always current, complete, or error-free.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Third-Party Content</h4>
                <p className="text-muted-foreground">
                  APKRoja hosts third-party applications and is not responsible for their functionality, 
                  security, or compliance with laws and regulations.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>8. Limitation of Liability</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                To the maximum extent permitted by law, APKRoja shall not be liable for any indirect, 
                incidental, special, consequential, or punitive damages, including but not limited to 
                loss of profits, data, use, goodwill, or other intangible losses, resulting from your 
                use of the Service.
              </p>
              <p className="text-muted-foreground mt-4">
                Our total liability for any claims arising from or related to the Service shall not 
                exceed the amount you paid us for the Service in the twelve months preceding the claim.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>9. Indemnification</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                You agree to defend, indemnify, and hold harmless APKRoja and its officers, directors, 
                employees, and agents from and against any claims, liabilities, damages, judgments, 
                awards, losses, costs, expenses, or fees arising out of or relating to your violation 
                of these Terms or your use of the Service.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>10. Termination</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We may terminate or suspend your access to the Service immediately, without prior notice 
                or liability, for any reason whatsoever, including without limitation if you breach the Terms.
              </p>
              <p className="text-muted-foreground mt-4">
                Upon termination, your right to use the Service will cease immediately. All provisions 
                of the Terms which by their nature should survive termination shall survive termination.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>11. Governing Law</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                These Terms shall be interpreted and governed by the laws of the jurisdiction in which 
                APKRoja operates, without regard to its conflict of law provisions. Any disputes arising 
                from these Terms or the Service shall be resolved in the courts of that jurisdiction.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>12. Changes to Terms</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We reserve the right to modify or replace these Terms at any time. If a revision is 
                material, we will try to provide at least 30 days notice prior to any new terms taking 
                effect. What constitutes a material change will be determined at our sole discretion.
              </p>
              <p className="text-muted-foreground mt-4">
                By continuing to access or use our Service after those revisions become effective, 
                you agree to be bound by the revised terms.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Mail className="w-5 h-5" />
                <span>13. Contact Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                If you have any questions about these Terms of Service, please contact us:
              </p>
              <div className="bg-muted/50 rounded-lg p-4">
                <p><strong>Email:</strong> legal@apkroja.com</p>
                <p><strong>Website:</strong> https://apkroja.com/contact</p>
                <p><strong>Response Time:</strong> We aim to respond within 48 hours</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default TermsPage

