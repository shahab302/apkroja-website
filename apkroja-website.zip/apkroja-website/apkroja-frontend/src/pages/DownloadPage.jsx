import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Download, Clock, Shield, CheckCircle, AlertTriangle, Smartphone, Star, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import AdBanner from '../components/AdBanner'

const DownloadPage = () => {
  const { slug } = useParams()
  const [app, setApp] = useState(null)
  const [countdown, setCountdown] = useState(8)
  const [isCountdownActive, setIsCountdownActive] = useState(false)
  const [showDownloadLink, setShowDownloadLink] = useState(false)
  const [downloadStarted, setDownloadStarted] = useState(false)

  useEffect(() => {
    // Mock app data - Replace with actual API call
    setApp({
      id: 1,
      name: 'WhatsApp Messenger',
      slug: 'whatsapp-messenger',
      version: '2.23.25.84',
      size: '58.2 MB',
      downloads: '5B+',
      rating: 4.1,
      icon: '/api/placeholder/120/120',
      category: 'Communication',
      description: 'Simple. Reliable. Private.',
      developer: 'WhatsApp LLC',
      lastUpdated: '2024-01-15',
      minAndroid: '4.1',
      downloadUrl: 'https://example.com/whatsapp.apk',
      features: [
        'End-to-end encryption',
        'Voice and video calls',
        'Group chats',
        'Status updates',
        'Document sharing'
      ],
      permissions: [
        'Camera',
        'Microphone',
        'Storage',
        'Contacts',
        'Location'
      ]
    })
  }, [slug])

  useEffect(() => {
    let timer
    if (isCountdownActive && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(countdown - 1)
      }, 1000)
    } else if (isCountdownActive && countdown === 0) {
      setShowDownloadLink(true)
      setIsCountdownActive(false)
    }
    return () => clearTimeout(timer)
  }, [countdown, isCountdownActive])

  const startCountdown = () => {
    setIsCountdownActive(true)
    setCountdown(8)
  }

  const handleDownload = () => {
    setDownloadStarted(true)
    // In a real app, this would trigger the actual download
    window.open(app.downloadUrl, '_blank')
  }

  if (!app) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading app details...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-muted-foreground">
            <li><Link to="/" className="hover:text-foreground">Home</Link></li>
            <li>/</li>
            <li><Link to={`/apps/${app.slug}`} className="hover:text-foreground">{app.name}</Link></li>
            <li>/</li>
            <li className="text-foreground">Download</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Download Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* App Info Card */}
            <Card>
              <CardHeader>
                <div className="flex items-start space-x-4">
                  <div className="w-24 h-24 rounded-xl bg-muted flex items-center justify-center overflow-hidden">
                    <Smartphone className="w-12 h-12 text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-2xl mb-2">{app.name}</CardTitle>
                    <CardDescription className="text-base mb-3">{app.description}</CardDescription>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span>{app.rating}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="w-4 h-4" />
                        <span>{app.downloads}</span>
                      </div>
                      <Badge variant="secondary">v{app.version}</Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Download Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Download className="w-5 h-5" />
                  <span>Download APK</span>
                </CardTitle>
                <CardDescription>
                  Click the button below to start the download process
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {!isCountdownActive && !showDownloadLink && (
                  <div className="text-center">
                    <Button 
                      onClick={startCountdown}
                      size="lg"
                      className="w-full md:w-auto px-8 py-3"
                    >
                      <Download className="w-5 h-5 mr-2" />
                      Prepare Download
                    </Button>
                    <p className="text-sm text-muted-foreground mt-2">
                      Click to start the download preparation
                    </p>
                  </div>
                )}

                {isCountdownActive && (
                  <div className="text-center space-y-4">
                    <div className="flex items-center justify-center space-x-2 text-lg">
                      <Clock className="w-5 h-5 text-primary" />
                      <span>Preparing download...</span>
                    </div>
                    <div className="text-4xl font-bold text-primary">{countdown}</div>
                    <Progress value={(8 - countdown) * 12.5} className="w-full max-w-md mx-auto" />
                    <p className="text-sm text-muted-foreground">
                      Please wait {countdown} seconds for the download link to appear
                    </p>
                  </div>
                )}

                {showDownloadLink && (
                  <div className="text-center space-y-4">
                    <div className="flex items-center justify-center space-x-2 text-green-600 mb-4">
                      <CheckCircle className="w-5 h-5" />
                      <span>Download ready!</span>
                    </div>
                    <Button 
                      onClick={handleDownload}
                      size="lg"
                      className="w-full md:w-auto px-8 py-3 bg-green-600 hover:bg-green-700"
                    >
                      <Download className="w-5 h-5 mr-2" />
                      Download APK ({app.size})
                    </Button>
                    {downloadStarted && (
                      <p className="text-sm text-green-600">
                        Download started! Check your downloads folder.
                      </p>
                    )}
                  </div>
                )}

                {/* Security Notice */}
                <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">
                        Safe Download
                      </h4>
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        This APK has been scanned for viruses and is safe to download. 
                        Always enable "Unknown sources" in your Android settings before installing.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Installation Instructions */}
            <Card>
              <CardHeader>
                <CardTitle>Installation Instructions</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>Download the APK file to your Android device</li>
                  <li>Go to Settings → Security → Enable "Unknown sources"</li>
                  <li>Open your file manager and locate the downloaded APK</li>
                  <li>Tap on the APK file to start installation</li>
                  <li>Follow the on-screen instructions to complete installation</li>
                </ol>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Ad Banner */}
            <AdBanner position="sidebar" />

            {/* App Details */}
            <Card>
              <CardHeader>
                <CardTitle>App Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Version</span>
                  <span>{app.version}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Size</span>
                  <span>{app.size}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Developer</span>
                  <span>{app.developer}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Category</span>
                  <span>{app.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Min Android</span>
                  <span>{app.minAndroid}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Last Updated</span>
                  <span>{app.lastUpdated}</span>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle>Key Features</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {app.features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Permissions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-500" />
                  <span>Permissions</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {app.permissions.map((permission, index) => (
                    <li key={index} className="text-sm text-muted-foreground">
                      • {permission}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DownloadPage

