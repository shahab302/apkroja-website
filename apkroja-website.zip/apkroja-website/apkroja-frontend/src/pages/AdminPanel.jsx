import { useState } from 'react'
import { Settings, Plus, Upload, Users, BarChart3, Shield, FileText, Eye } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'

const AdminPanel = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loginForm, setLoginForm] = useState({ username: '', password: '' })

  // Mock authentication
  const handleLogin = (e) => {
    e.preventDefault()
    if (loginForm.username === 'admin' && loginForm.password === 'admin') {
      setIsAuthenticated(true)
    } else {
      alert('Invalid credentials. Use admin/admin for demo.')
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center py-8">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Admin Login</CardTitle>
            <CardDescription className="text-center">
              Access the APKRoja admin panel
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label htmlFor="username" className="block text-sm font-medium mb-2">
                  Username
                </label>
                <Input
                  id="username"
                  type="text"
                  value={loginForm.username}
                  onChange={(e) => setLoginForm(prev => ({ ...prev, username: e.target.value }))}
                  placeholder="Enter username"
                  required
                />
              </div>
              <div>
                <label htmlFor="password" className="block text-sm font-medium mb-2">
                  Password
                </label>
                <Input
                  id="password"
                  type="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="Enter password"
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Login
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                Demo credentials: admin / admin
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  const stats = [
    { title: 'Total Apps', value: '50,247', icon: FileText, change: '+12%' },
    { title: 'Downloads Today', value: '125,430', icon: BarChart3, change: '+8%' },
    { title: 'Active Users', value: '1.2M', icon: Users, change: '+15%' },
    { title: 'Security Scans', value: '99.9%', icon: Shield, change: '0%' }
  ]

  const recentApps = [
    { name: 'WhatsApp Messenger', version: '2.23.25.84', status: 'approved', downloads: '5B+' },
    { name: 'Instagram', version: '302.0.0.23.114', status: 'pending', downloads: '1B+' },
    { name: 'TikTok', version: '32.8.4', status: 'approved', downloads: '1B+' }
  ]

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Admin Panel</h1>
            <p className="text-muted-foreground">Manage your APK download platform</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline">
              <Eye className="w-4 h-4 mr-2" />
              View Site
            </Button>
            <Button onClick={() => setIsAuthenticated(false)}>
              Logout
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <stat.icon className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <div className="mt-4">
                  <span className={`text-sm ${stat.change.startsWith('+') ? 'text-green-600' : 'text-muted-foreground'}`}>
                    {stat.change} from last month
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content */}
        <Tabs defaultValue="apps" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="apps">Apps</TabsTrigger>
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Apps Management */}
          <TabsContent value="apps" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">App Management</h2>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add New App
              </Button>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Recent Apps</CardTitle>
                <CardDescription>Latest apps added to the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentApps.map((app, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
                          <FileText className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{app.name}</h3>
                          <p className="text-sm text-muted-foreground">v{app.version}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge variant={app.status === 'approved' ? 'default' : 'secondary'}>
                          {app.status}
                        </Badge>
                        <span className="text-sm text-muted-foreground">{app.downloads}</span>
                        <Button variant="outline" size="sm">Edit</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Upload New App */}
          <TabsContent value="upload" className="space-y-6">
            <h2 className="text-2xl font-semibold">Upload New App</h2>
            
            <Card>
              <CardHeader>
                <CardTitle>App Information</CardTitle>
                <CardDescription>Fill in the details for the new app</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">App Name</label>
                    <Input placeholder="Enter app name" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Version</label>
                    <Input placeholder="e.g., 1.0.0" />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Category</label>
                    <Input placeholder="e.g., Communication" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Developer</label>
                    <Input placeholder="Developer name" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Textarea placeholder="App description..." rows={4} />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">APK File</label>
                  <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                    <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">Drag and drop APK file here, or click to browse</p>
                    <Button variant="outline" className="mt-4">
                      Choose File
                    </Button>
                  </div>
                </div>

                <Button className="w-full">
                  Upload App
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users */}
          <TabsContent value="users" className="space-y-6">
            <h2 className="text-2xl font-semibold">User Management</h2>
            <Card>
              <CardContent className="p-8 text-center">
                <Users className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">User Management</h3>
                <p className="text-muted-foreground">
                  User management features will be available in the full version.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-6">
            <h2 className="text-2xl font-semibold">Analytics</h2>
            <Card>
              <CardContent className="p-8 text-center">
                <BarChart3 className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">Analytics Dashboard</h3>
                <p className="text-muted-foreground">
                  Detailed analytics and reporting features will be available in the full version.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings */}
          <TabsContent value="settings" className="space-y-6">
            <h2 className="text-2xl font-semibold">Settings</h2>
            <Card>
              <CardContent className="p-8 text-center">
                <Settings className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">System Settings</h3>
                <p className="text-muted-foreground">
                  Configuration and settings panel will be available in the full version.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default AdminPanel

