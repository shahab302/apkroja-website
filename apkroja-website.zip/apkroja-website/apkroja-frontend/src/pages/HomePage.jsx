import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Download, Star, Users, Shield, Clock, TrendingUp } from 'lucide-react'
import AdBanner from '../components/AdBanner'
import SEO from '../components/SEO'
import apiService from '../services/api'

const HomePage = () => {
  const [featuredApps, setFeaturedApps] = useState([])
  const [recentApps, setRecentApps] = useState([])
  const [popularApps, setPopularApps] = useState([])
  const [categories, setCategories] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        
        // Fetch all data in parallel
        const [
          featuredResponse,
          recentResponse,
          popularResponse,
          categoriesResponse,
          statsResponse
        ] = await Promise.all([
          apiService.getFeaturedApps(6),
          apiService.getRecentApps(6),
          apiService.getPopularApps(6),
          apiService.getCategories(),
          apiService.getPublicStats()
        ])

        setFeaturedApps(featuredResponse.apps || [])
        setRecentApps(recentResponse.apps || [])
        setPopularApps(popularResponse.apps || [])
        setCategories(categoriesResponse.categories || [])
        setStats(statsResponse)
        
      } catch (err) {
        console.error('Error fetching homepage data:', err)
        setError('Failed to load data. Please try again later.')
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const AppCard = ({ app }) => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-shadow p-4">
      <div className="flex items-start space-x-3">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
          {app.name.charAt(0)}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-900 dark:text-white truncate">
            {app.name}
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
            {app.developer}
          </p>
          <div className="flex items-center space-x-4 mt-2">
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {app.rating}
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <Download className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {app.download_count_display}
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <span className="text-sm text-gray-500 dark:text-gray-400">
          v{app.version} • {app.file_size}
        </span>
        <Link
          to={`/apps/${app.slug}`}
          className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors"
        >
          Download
        </Link>
      </div>
    </div>
  )

  const CategoryCard = ({ category }) => (
    <Link
      to={`/category/${category.slug}`}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all p-6 text-center group"
    >
      <div className={`w-12 h-12 mx-auto mb-3 rounded-lg bg-${category.color}-100 dark:bg-${category.color}-900 flex items-center justify-center group-hover:scale-110 transition-transform`}>
        <div className={`w-6 h-6 text-${category.color}-600 dark:text-${category.color}-400`}>
          {/* Icon placeholder - in a real app, you'd use the actual icon */}
          <div className="w-full h-full bg-current rounded"></div>
        </div>
      </div>
      <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
        {category.name}
      </h3>
      <p className="text-sm text-gray-600 dark:text-gray-400">
        {category.app_count} apps
      </p>
    </Link>
  )

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 dark:text-red-400 mb-4">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
          >
            Try Again
          </button>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO 
        title="Download Free Android APK Files & Games"
        description="Download free Android APK files and games safely. Fast downloads, virus-free apps, and the latest versions of your favorite Android applications."
        keywords="APK download, Android apps, free apps, mobile games, APK files"
        url="/"
      />
      
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Download Free Android APKs
              </h1>
              <p className="text-xl md:text-2xl mb-8 text-green-100">
                Safe, fast, and reliable APK downloads for your Android device
              </p>
              
              {stats && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                  <div className="text-center">
                    <div className="text-3xl font-bold">{stats.total_apps?.toLocaleString()}</div>
                    <div className="text-green-200">Total Apps</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold">{stats.total_downloads?.toLocaleString()}</div>
                    <div className="text-green-200">Downloads</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold">{stats.security_scan_rate}%</div>
                    <div className="text-green-200">Safe Downloads</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold">{stats.support_availability}</div>
                    <div className="text-green-200">Support</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Categories Section */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Browse by Category
              </h2>
              <p className="text-gray-600 dark:text-gray-400">
                Find apps and games in your favorite categories
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {categories.slice(0, 6).map((category) => (
                <CategoryCard key={category.id} category={category} />
              ))}
            </div>
          </div>
        </section>

        {/* Ad Banner */}
        <AdBanner position="content" />

        {/* Featured Apps Section */}
        {featuredApps.length > 0 && (
          <section className="py-16 bg-white dark:bg-gray-800">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                    Featured Apps
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Hand-picked apps recommended by our team
                  </p>
                </div>
                <Link
                  to="/apps?featured=true"
                  className="text-green-600 hover:text-green-700 font-medium"
                >
                  View All →
                </Link>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredApps.map((app) => (
                  <AppCard key={app.id} app={app} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Recent Apps Section */}
        {recentApps.length > 0 && (
          <section className="py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                    <Clock className="inline w-8 h-8 mr-2" />
                    Recently Added
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Latest apps and updates
                  </p>
                </div>
                <Link
                  to="/apps?sort=recent"
                  className="text-green-600 hover:text-green-700 font-medium"
                >
                  View All →
                </Link>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recentApps.map((app) => (
                  <AppCard key={app.id} app={app} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Popular Apps Section */}
        {popularApps.length > 0 && (
          <section className="py-16 bg-white dark:bg-gray-800">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                    <TrendingUp className="inline w-8 h-8 mr-2" />
                    Most Popular
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Most downloaded apps this month
                  </p>
                </div>
                <Link
                  to="/apps?sort=popular"
                  className="text-green-600 hover:text-green-700 font-medium"
                >
                  View All →
                </Link>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {popularApps.map((app) => (
                  <AppCard key={app.id} app={app} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Trust Indicators */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <Shield className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  100% Safe Downloads
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  All APK files are scanned for viruses and malware before being made available for download.
                </p>
              </div>
              <div className="text-center">
                <Download className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Fast Downloads
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  High-speed servers ensure quick downloads so you can get your apps installed faster.
                </p>
              </div>
              <div className="text-center">
                <Users className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Trusted by Millions
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Join millions of users who trust APKRoja for their Android app download needs.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Bottom Ad Banner */}
        <AdBanner position="footer" />
      </div>
    </>
  )
}

export default HomePage

