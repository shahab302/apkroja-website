import { useEffect } from 'react'

const AdBanner = ({ position, className = '' }) => {
  useEffect(() => {
    // Initialize Google AdSense ads when component mounts
    try {
      if (window.adsbygoogle) {
        window.adsbygoogle.push({})
      }
    } catch (error) {
      console.log('AdSense error:', error)
    }
  }, [])

  const getAdConfig = () => {
    switch (position) {
      case 'header':
        return {
          style: { display: 'block', width: '100%', height: '90px' },
          'data-ad-format': 'horizontal',
          'data-ad-slot': '1234567890', // Replace with actual ad slot
          'data-full-width-responsive': 'true'
        }
      case 'sidebar':
        return {
          style: { display: 'block', width: '300px', height: '250px' },
          'data-ad-format': 'rectangle',
          'data-ad-slot': '1234567891', // Replace with actual ad slot
        }
      case 'content':
        return {
          style: { display: 'block', width: '100%', height: '280px' },
          'data-ad-format': 'auto',
          'data-ad-slot': '1234567892', // Replace with actual ad slot
          'data-full-width-responsive': 'true'
        }
      case 'footer':
        return {
          style: { display: 'block', width: '100%', height: '90px' },
          'data-ad-format': 'horizontal',
          'data-ad-slot': '1234567893', // Replace with actual ad slot
          'data-full-width-responsive': 'true'
        }
      default:
        return {
          style: { display: 'block', width: '100%', height: '250px' },
          'data-ad-format': 'auto',
          'data-ad-slot': '1234567894', // Replace with actual ad slot
          'data-full-width-responsive': 'true'
        }
    }
  }

  const adConfig = getAdConfig()

  return (
    <div className={`ad-container ${className}`}>
      {/* Placeholder for development - Replace with actual AdSense code */}
      <div className="bg-muted/30 border-2 border-dashed border-muted-foreground/20 rounded-lg flex items-center justify-center text-muted-foreground text-sm" style={adConfig.style}>
        <div className="text-center">
          <div className="font-medium">Advertisement</div>
          <div className="text-xs mt-1">{position} ad placement</div>
        </div>
      </div>
      
      {/* Actual Google AdSense code - Uncomment when ready to use */}
      {/*
      <ins
        className="adsbygoogle"
        style={adConfig.style}
        data-ad-client="ca-pub-XXXXXXXXXXXXXXXX" // Replace with your AdSense client ID
        data-ad-slot={adConfig['data-ad-slot']}
        data-ad-format={adConfig['data-ad-format']}
        data-full-width-responsive={adConfig['data-full-width-responsive']}
      ></ins>
      */}
    </div>
  )
}

export default AdBanner

