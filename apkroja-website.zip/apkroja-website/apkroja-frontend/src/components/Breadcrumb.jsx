import { Link } from 'react-router-dom'
import { ChevronRight, Home } from 'lucide-react'

const Breadcrumb = ({ items = [] }) => {
  // Always include home as the first item
  const breadcrumbItems = [
    { name: 'Home', url: '/', icon: Home },
    ...items
  ]

  return (
    <nav aria-label="Breadcrumb" className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400 mb-4">
      {breadcrumbItems.map((item, index) => (
        <div key={index} className="flex items-center">
          {index > 0 && (
            <ChevronRight className="w-4 h-4 mx-2 text-gray-400" />
          )}
          
          {index === breadcrumbItems.length - 1 ? (
            // Current page (not clickable)
            <span className="flex items-center text-gray-900 dark:text-gray-100 font-medium">
              {item.icon && <item.icon className="w-4 h-4 mr-1" />}
              {item.name}
            </span>
          ) : (
            // Clickable breadcrumb item
            <Link
              to={item.url}
              className="flex items-center hover:text-green-600 dark:hover:text-green-400 transition-colors"
            >
              {item.icon && <item.icon className="w-4 h-4 mr-1" />}
              {item.name}
            </Link>
          )}
        </div>
      ))}
    </nav>
  )
}

export default Breadcrumb

