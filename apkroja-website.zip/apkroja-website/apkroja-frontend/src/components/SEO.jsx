import { Helmet } from 'react-helmet-async'

const SEO = ({ 
  title, 
  description, 
  keywords, 
  image, 
  url, 
  type = 'website',
  app = null,
  breadcrumbs = [],
  structuredData = null
}) => {
  const siteTitle = 'APKRoja - Download Free Android APK Files & Games'
  const siteDescription = 'Download free Android APK files and games safely. Fast downloads, virus-free apps, and the latest versions of your favorite Android applications.'
  const siteUrl = 'https://apkroja.com'
  const defaultImage = `${siteUrl}/images/og-image.jpg`

  const pageTitle = title ? `${title} | ${siteTitle}` : siteTitle
  const pageDescription = description || siteDescription
  const pageImage = image || defaultImage
  const pageUrl = url ? `${siteUrl}${url}` : siteUrl
  const pageKeywords = keywords || 'APK download, Android apps, free apps, mobile games, APK files'

  // Generate structured data for apps
  const generateAppStructuredData = (appData) => {
    return {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      "name": appData.name,
      "description": appData.description,
      "applicationCategory": "MobileApplication",
      "operatingSystem": "Android",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "USD"
      },
      "aggregateRating": appData.rating ? {
        "@type": "AggregateRating",
        "ratingValue": appData.rating,
        "ratingCount": appData.rating_count,
        "bestRating": "5",
        "worstRating": "1"
      } : undefined,
      "author": {
        "@type": "Organization",
        "name": appData.developer
      },
      "downloadUrl": pageUrl,
      "fileSize": appData.file_size,
      "version": appData.version,
      "datePublished": appData.created_at,
      "dateModified": appData.updated_at,
      "screenshot": appData.screenshots ? JSON.parse(appData.screenshots) : undefined
    }
  }

  // Generate breadcrumb structured data
  const generateBreadcrumbStructuredData = (breadcrumbs) => {
    if (!breadcrumbs.length) return null

    return {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": breadcrumbs.map((crumb, index) => ({
        "@type": "ListItem",
        "position": index + 1,
        "name": crumb.name,
        "item": `${siteUrl}${crumb.url}`
      }))
    }
  }

  // Generate organization structured data
  const organizationStructuredData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "APKRoja",
    "url": siteUrl,
    "logo": `${siteUrl}/images/logo.png`,
    "description": siteDescription,
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-555-0123",
      "contactType": "customer service",
      "email": "support@apkroja.com"
    },
    "sameAs": [
      "https://twitter.com/apkroja",
      "https://facebook.com/apkroja",
      "https://instagram.com/apkroja"
    ]
  }

  // Generate website structured data
  const websiteStructuredData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": siteTitle,
    "url": siteUrl,
    "description": siteDescription,
    "potentialAction": {
      "@type": "SearchAction",
      "target": {
        "@type": "EntryPoint",
        "urlTemplate": `${siteUrl}/search?q={search_term_string}`
      },
      "query-input": "required name=search_term_string"
    }
  }

  // Combine all structured data
  const allStructuredData = [
    organizationStructuredData,
    websiteStructuredData
  ]

  if (app) {
    allStructuredData.push(generateAppStructuredData(app))
  }

  if (breadcrumbs.length > 0) {
    const breadcrumbData = generateBreadcrumbStructuredData(breadcrumbs)
    if (breadcrumbData) {
      allStructuredData.push(breadcrumbData)
    }
  }

  if (structuredData) {
    allStructuredData.push(structuredData)
  }

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{pageTitle}</title>
      <meta name="description" content={pageDescription} />
      <meta name="keywords" content={pageKeywords} />
      <meta name="author" content="APKRoja" />
      <meta name="robots" content="index, follow" />
      <meta name="language" content="English" />
      <meta name="revisit-after" content="1 days" />
      
      {/* Canonical URL */}
      <link rel="canonical" href={pageUrl} />
      
      {/* Open Graph Meta Tags */}
      <meta property="og:title" content={pageTitle} />
      <meta property="og:description" content={pageDescription} />
      <meta property="og:image" content={pageImage} />
      <meta property="og:url" content={pageUrl} />
      <meta property="og:type" content={type} />
      <meta property="og:site_name" content="APKRoja" />
      <meta property="og:locale" content="en_US" />
      
      {/* Twitter Card Meta Tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={pageTitle} />
      <meta name="twitter:description" content={pageDescription} />
      <meta name="twitter:image" content={pageImage} />
      <meta name="twitter:site" content="@apkroja" />
      <meta name="twitter:creator" content="@apkroja" />
      
      {/* Mobile Meta Tags */}
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta name="mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      
      {/* Theme Color */}
      <meta name="theme-color" content="#10b981" />
      <meta name="msapplication-TileColor" content="#10b981" />
      
      {/* Additional SEO Meta Tags */}
      <meta name="distribution" content="global" />
      <meta name="rating" content="general" />
      <meta name="copyright" content="APKRoja" />
      <meta name="generator" content="APKRoja CMS" />
      
      {/* Structured Data */}
      {allStructuredData.map((data, index) => (
        <script key={index} type="application/ld+json">
          {JSON.stringify(data)}
        </script>
      ))}
      
      {/* Preconnect to external domains */}
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
      <link rel="preconnect" href="https://www.googletagmanager.com" />
      <link rel="preconnect" href="https://www.google-analytics.com" />
      <link rel="preconnect" href="https://pagead2.googlesyndication.com" />
      
      {/* DNS Prefetch */}
      <link rel="dns-prefetch" href="//fonts.googleapis.com" />
      <link rel="dns-prefetch" href="//www.googletagmanager.com" />
      <link rel="dns-prefetch" href="//www.google-analytics.com" />
      <link rel="dns-prefetch" href="//pagead2.googlesyndication.com" />
    </Helmet>
  )
}

export default SEO

