// Sitemap generator utility for SEO
export const generateSitemap = (apps = [], categories = []) => {
  const baseUrl = 'https://apkroja.com'
  const currentDate = new Date().toISOString().split('T')[0]

  // Static pages with their priorities and change frequencies
  const staticPages = [
    { url: '', priority: '1.0', changefreq: 'daily' }, // Homepage
    { url: '/apps', priority: '0.9', changefreq: 'daily' },
    { url: '/games', priority: '0.9', changefreq: 'daily' },
    { url: '/tools', priority: '0.8', changefreq: 'weekly' },
    { url: '/search', priority: '0.7', changefreq: 'weekly' },
    { url: '/about', priority: '0.5', changefreq: 'monthly' },
    { url: '/contact', priority: '0.5', changefreq: 'monthly' },
    { url: '/privacy', priority: '0.4', changefreq: 'yearly' },
    { url: '/terms', priority: '0.4', changefreq: 'yearly' }
  ]

  let sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
`

  // Add static pages
  staticPages.forEach(page => {
    sitemap += `  <url>
    <loc>${baseUrl}${page.url}</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>
`
  })

  // Add category pages
  categories.forEach(category => {
    sitemap += `  <url>
    <loc>${baseUrl}/category/${category.slug}</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
`
  })

  // Add app pages
  apps.forEach(app => {
    const lastmod = app.updated_at ? new Date(app.updated_at).toISOString().split('T')[0] : currentDate
    
    sitemap += `  <url>
    <loc>${baseUrl}/apps/${app.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>`

    // Add app screenshots as images
    if (app.screenshots) {
      try {
        const screenshots = JSON.parse(app.screenshots)
        screenshots.forEach(screenshot => {
          sitemap += `
    <image:image>
      <image:loc>${screenshot}</image:loc>
      <image:title>${app.name} Screenshot</image:title>
      <image:caption>Screenshot of ${app.name} v${app.version}</image:caption>
    </image:image>`
        })
      } catch (e) {
        // Handle invalid JSON
      }
    }

    sitemap += `
  </url>
`

    // Add download pages
    sitemap += `  <url>
    <loc>${baseUrl}/download/${app.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
`
  })

  sitemap += `</urlset>`

  return sitemap
}

// Generate robots.txt content
export const generateRobotsTxt = () => {
  const baseUrl = 'https://apkroja.com'
  
  return `User-agent: *
Allow: /

# Disallow admin and private areas
Disallow: /admin
Disallow: /api/
Disallow: /private/

# Allow important crawlers
User-agent: Googlebot
Allow: /

User-agent: Bingbot
Allow: /

# Sitemap location
Sitemap: ${baseUrl}/sitemap.xml

# Crawl delay (optional)
Crawl-delay: 1`
}

// Generate structured data for FAQ pages
export const generateFAQStructuredData = (faqs) => {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  }
}

// Generate structured data for How-To guides
export const generateHowToStructuredData = (title, steps) => {
  return {
    "@context": "https://schema.org",
    "@type": "HowTo",
    "name": title,
    "description": `Learn how to ${title.toLowerCase()}`,
    "step": steps.map((step, index) => ({
      "@type": "HowToStep",
      "position": index + 1,
      "name": step.name,
      "text": step.text,
      "image": step.image || undefined
    }))
  }
}

// Generate structured data for reviews
export const generateReviewStructuredData = (app, reviews) => {
  if (!reviews || reviews.length === 0) return null

  return {
    "@context": "https://schema.org",
    "@type": "Product",
    "name": app.name,
    "description": app.description,
    "brand": {
      "@type": "Brand",
      "name": app.developer
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": app.rating,
      "reviewCount": reviews.length,
      "bestRating": "5",
      "worstRating": "1"
    },
    "review": reviews.slice(0, 5).map(review => ({
      "@type": "Review",
      "author": {
        "@type": "Person",
        "name": review.user_name
      },
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": review.rating,
        "bestRating": "5",
        "worstRating": "1"
      },
      "reviewBody": review.comment,
      "datePublished": review.created_at
    }))
  }
}

// SEO utility functions
export const generateMetaDescription = (app) => {
  return `Download ${app.name} v${app.version} APK for Android. ${app.short_description} Free, safe, and fast download. File size: ${app.file_size}. Developer: ${app.developer}.`
}

export const generateMetaKeywords = (app) => {
  const baseKeywords = ['APK download', 'Android app', 'free download', 'mobile app']
  const appKeywords = [
    app.name,
    app.developer,
    app.category?.name,
    'APK file',
    'Android',
    'mobile'
  ]
  
  return [...baseKeywords, ...appKeywords].filter(Boolean).join(', ')
}

export const generatePageTitle = (app, page = 'detail') => {
  switch (page) {
    case 'download':
      return `Download ${app.name} v${app.version} APK for Android - Free & Safe`
    case 'detail':
      return `${app.name} v${app.version} APK Download - ${app.short_description}`
    default:
      return `${app.name} - Free Android APK Download`
  }
}

